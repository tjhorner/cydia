// what color would you like? (default=5EB8D4) (enter hex color code without '#')
var color = "5EB8D4";

// would you like transparency? (default=true) if so, how transparent would you like it to be? e.g. 1 for no transparency and 0 for complete transparency (default=.6)
var transparent = true;
var transparency = ".6"

// would you like to show the weather? (default=true) also enter your yahoo WOEID
var weather = true;
var WOEID = "2514383";

// would you like to show the date? (default=true)
var date = true;

// would you like to use 12h time? (default=true) if so, where would you like to display the am/pm? (default=bottom)
var h12 = true;
var ampmpos = "top"

// would you like to show your next alarm? (default=true)
var alarm = true;

// would you like to show your next calendar event? (default=true)
var calendar = true;

// would you like to show the swipe text at the bottom of the screen? (default=true)
var swipe = true;

// would you like to display the battery level? (default=true) if so, where? (default=bottom)
var battery = true;
var battpos = "bottom"
