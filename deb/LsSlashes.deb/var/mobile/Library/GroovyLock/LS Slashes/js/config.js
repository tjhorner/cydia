var h12 = true;
var color = "FFFFFF";
