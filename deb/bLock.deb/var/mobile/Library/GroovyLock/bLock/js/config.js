var dark_theme = false;
var h12 = true;
var battery = true;
