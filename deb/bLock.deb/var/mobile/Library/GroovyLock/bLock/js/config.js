var dark_theme = false;
var battery = true;
